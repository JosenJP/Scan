#ifndef EXTENSION_HELPER_HPP
#define EXTENSION_HELPER_HPP

class ExtensionHelper
{
public:
    ExtensionHelper() {};
    ~ExtensionHelper() {};

    static bool CheckExtension(const char* a_pFileName, const char* a_pExtension);

private:

};

#endif // !EXTENSION_HELPER_HPP


